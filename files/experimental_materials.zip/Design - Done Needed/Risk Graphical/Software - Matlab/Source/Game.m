function varargout = Game(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name', mfilename, 'gui_Singleton',  gui_Singleton, 'gui_OpeningFcn', @Game_OpeningFcn, 'gui_OutputFcn',  @Game_OutputFcn, 'gui_LayoutFcn',  [] , 'gui_Callback',[]);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Game is made visible.
function Game_OpeningFcn(hObject, eventdata, handles, varargin)
global State x_ind y_ind a b t i_subject alpha current_trial exp_state choice ;
global subject_ID save_flag save_and_continue show_points_status N_rounds N_practices T exchange_rate;
global ChooseExpOrPractice prac_or_exp;

%The following function manages the different states of the mouse
State = struct('WaitForClick',1, 'ExperimentShutdown', 2 ,'WaitForT',3 ,'Work',4, 'WaitForClick2',5,...
        'WaitForClick3',6, 'WaitForClick4',7, 'WaitForClick5',8, 'WaitForClick6',9, 'WaitForClick7',10);

% The following function chooses whether we are in practice or the real experiment
ChooseExpOrPractice = struct('Practice',1, 'Experiment',2); 

exp_state = State.ExperimentShutdown; 
prac_or_exp = ChooseExpOrPractice.Practice; 

% Choose default command line output for Game
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);

rng('shuffle');
N_practices = 5;
N_rounds = randi([10 50]);
T = randi([3 12]);  % T represents the difficulty of the slopes in the experiment

    if T==3
       exchange_rate = 40;
    elseif T==4
       exchange_rate = 35;
    elseif T==5
       exchange_rate = 30;
    elseif T==6
       exchange_rate = 25;
    elseif T==7
       exchange_rate = 25;   
    elseif T==8
       exchange_rate = 20;
    elseif T==9
       exchange_rate = 20;
    elseif T==10
       exchange_rate = 15;
    elseif T==11
       exchange_rate = 15;
    elseif T==12
       exchange_rate = 15;
    end

set(handles.RoundsPerSessionTxt,'String',N_practices);
show_points_status = 'Yes';  %questdlg('Show main points on line?', 'Settings', 'Yes', 'No', 'Yes');
save_and_continue = handles.SaveContinue;
subject_ID = inputdlg({'Enter subject''s ID number:'}, 'Subject ID');
save_flag = false;
%end_game = handles.end_game;
%set(end_game,'Enable','off', 'FontName', 'David');

%elseif prac_or_exp==ChooseExpOrPractice.Practice
current_trial = 1;
i_subject = [2, 1, 1, 1, 2];
t = [2, 3, 5, 1, 8];
alpha = [60, 75, 44, 80, 27];
b = zeros(5,1);
tmp = zeros(5,1);
a = zeros(5,1);
    for z = 1:5
        if i_subject(z)==1
            b(z)= alpha(z);
            tmp(z) = alpha(z).*t(z);
            a(z) = -(b(z))/(tmp(z));
        else
            b(z)= alpha(z).*t(z);
            tmp(z) = alpha(z);
            a(z) = -(b(z))/(tmp(z));
        end
    end
 set(handles.Round, 'String', 1);
    
%end

%set(handles.BlackScreen, 'Visible', 'off');


function plot_current_trial()
    global current_trial x_ind y_ind a b show_points_status i_subject axis_lim_y axis_lim_x
    if i_subject(current_trial)==1
        axis_lim_x = -(b(current_trial)/a(current_trial)) + 30;
        axis_lim_y = axis_lim_x;
    else
        axis_lim_y = b(current_trial) + 30;
        axis_lim_x = axis_lim_y;
    end
    x_ind = 0:0.1:axis_lim_x;
    y_ind = a(current_trial)*x_ind + b(current_trial);
    plot(x_ind, y_ind, 'k', 'linewidth', 3); set(gca,'FontSize',16, 'FontName', 'David', 'FontWeight', 'bold');    
    
    axis ([0 axis_lim_x 0 axis_lim_y]); grid on; set(gca,'FontSize',16, 'FontName', 'David', 'FontWeight', 'bold'); axis square;
    %set(gca,'DefaultTextFontName', 'David');
    %set(gca,'DefaultAxesFontName', 'Arial');
    
    ylabel('���� Y');
    xlabel('���� X');
    
    if  axis_lim_y > 500
       set(gca,'YTick',0:100:axis_lim_y); 
       set(gca,'XTick',0:100:axis_lim_x);
    elseif axis_lim_y > 250 && axis_lim_y <=500
       set(gca,'YTick',0:50:axis_lim_y); 
       set(gca,'XTick',0:50:axis_lim_x);
    elseif axis_lim_y <= 250 && axis_lim_y > 100
       set(gca,'YTick',0:20:axis_lim_y); 
       set(gca,'XTick',0:20:axis_lim_x);
    else 
       set(gca,'YTick',0:10:axis_lim_y); 
       set(gca,'XTick',0:10:axis_lim_x);
    end
    
    if strcmp(show_points_status, 'Yes')
        hold on;
        %plot(x_ind(1), y_ind(1), 'ro', 'linewidth', 3);
        ind = find(y_ind>0,1,'last');
        %plot(x_ind(ind), y_ind(ind), 'ro', 'linewidth', 3);
    end

% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
 set(gcf, 'WindowButtonMotionFcn',@mouseMove);
 set(gcf,'WindowButtonDownFcn',@mytestcallback);

    
% --- Outputs from this function are returned to the command line.
function varargout = Game_OutputFcn(hObject, eventdata, handles)
global GHandles exp_state prac_or_exp

set(gcf, 'units','normalized','outerposition',[0 0 1 1]);

State = struct('WaitForClick',1, 'ExperimentShutdown', 2 ,'WaitForT',3 ,'Work',4, 'WaitForClick2',5,...
        'WaitForClick3',6, 'WaitForClick4',7, 'WaitForClick5',8, 'WaitForClick6',9, 'WaitForClick7',10);

ChooseExpOrPractice = struct('Practice',1, 'Experiment',2); 
exp_state = State.ExperimentShutdown;
prac_or_exp = ChooseExpOrPractice.Practice;

GHandles = handles;
set(handles.BlackScreen, 'Visible', 'on');

firstmsg = [char(10) '������ ����� ������!'...
            char(10)...
            char(10) '��� �������...'...
            ];
set(handles.BlackScreen, 'String',prepareForBlackScreenShow(firstmsg), 'FontName', 'David');
pause(1)
StartPassword = 'notgood';
    while isempty(StartPassword) || strcmp(StartPassword,'123456') ~= 1
        StartPassword = inputdlg({'Please enter password:'}, 'Wait for Password before continue');
    end

reminder = ['������ ����:'....
             char(10) '��� ���� ����� ����� �� ������ ������ �������'...
             char(10) '�� �������� ��� ��� ������, X �-Y.'...
             char(10) '���� ������ ���� ��� ������ ��� �����,'...
             char(10) '������� ����� ��� ��� ������� X �-Y.'...
             char(10) '��� ���� ���� ����� ���� ����� �����.'...
             char(10) ...
             char(10) '������� ����� ����/� ���� �� ����� �� ������ �� ��/� �������/�.'...
             char(10) '����/� �������/� ���� �����, ��� ���/� �� ���� ������ �����.'...
             char(10) '���/� �� ������ ������� ����� �� ����� �-"����/� �����/�"'...
             char(10) ....
             char(10) '����� ��� �� �����, ��� ���/� ������/��.'...
             char(10) ...
             char(10) '���/� �� ����� �����'];

exp_state = State.WaitForClick;
set(handles.BlackScreen, 'String',prepareForBlackScreenShow(reminder), 'FontName', 'David');

varargout{1} = handles.output;


% --- Executes on button press in SaveContinue.
function SaveContinue_Callback(hObject, eventdata, handles)
global GHandles;
global save_and_continue N_rounds N_practices;
global current_trial choice T exchange_rate exp_state prac_or_exp chosen_axis;
global chosen_trial winning_points_X winning_points_Y winning_points_X_str
global winning_points_Y_str winning_points winning_prize

State = struct('WaitForClick',1, 'ExperimentShutdown', 2 ,'WaitForT',3 ,'Work',4, 'WaitForClick2',5,...
        'WaitForClick3',6, 'WaitForClick4',7, 'WaitForClick5',8, 'WaitForClick6',9, 'WaitForClick7',10);

ChooseExpOrPractice = struct('Practice',1, 'Experiment',2); 

axes(GHandles.axes1);
cla();

if prac_or_exp == ChooseExpOrPractice.Experiment
    choice{current_trial+1, 6} = toc;   
    current_trial = current_trial + 1;
    if current_trial > N_rounds
        %exp_state = State.WaitForClick;
        chosen_trial = ceil((current_trial-1)*rand(1));
        possible_axis = {'X','Y'};
        chosen_axis = possible_axis{(randi(2))};
        winning_points_X= choice{chosen_trial+1, 4};
        winning_points_Y= choice{chosen_trial+1, 5};
                if chosen_axis == 'X'
                    winning_points = winning_points_X;
                else
                    winning_points = winning_points_Y;
                end
        winning_points_X_str = num2str(winning_points_X);
        winning_points_Y_str = num2str(winning_points_Y);
        winning_prize = exchange_rate.*(winning_points)*0.01;
    
        choice{current_trial+2,1} = 'Chosen Trial';
        choice{current_trial+2,2} = chosen_trial;
        choice{current_trial+3,1} = 'Winning Points - X';
        choice{current_trial+3,2} = winning_points_X;
        choice{current_trial+4,1} = 'Winning Points - Y';
        choice{current_trial+4,2} = winning_points_Y;
        choice{current_trial+5,1} = 'Subject''s T';
        choice{current_trial+5,2} = T;
        choice{current_trial+6,1} = 'Eachange rate';
        choice{current_trial+6,2} = exchange_rate;
        choice{current_trial+7,1} = 'Number of trials';
        choice{current_trial+7,2} = N_rounds;
    
        set(save_and_continue,'Enable','off', 'FontName', 'David');
        set(GHandles.BlackScreen, 'Visible', 'on');
    
        %exp_state = State.WaitForClick;
        msg1 = ['������ ������.'...
                char(10) ...
                char(10) '���/� �� ����� �����'];
    
        set(GHandles.BlackScreen, 'String', prepareForBlackScreenShow(msg1), 'FontName', 'David');
%         pause(5);
    
        FinishPassword = 'notgood';
        while isempty(FinishPassword) || strcmp(FinishPassword,'papi') ~= 1
            FinishPassword = inputdlg({'Please enter experimenter''s password:'}, 'Wait for Password before continue');
        end
        
        msg2 = ['���� ������ ������ ����� ����: ' ...
             char(10) '���� ���� ' num2str(chosen_trial) '.'...
             char(10) '����� �� ���� ' winning_points_X_str ' �������� ����� X,'...
             char(10) '�-' winning_points_Y_str ' �������� ����� Y.'...
             char(10)...
             char(10) '��� ����� ������ ��� ' num2str(exchange_rate) ' ������.' ...  
             char(10) '���� ������ ����/� ����� ������, ������/� �� ����� �����.'...
             char(10) '���� ��������� ������ ����� ����� ���� ������ �����.'...
             char(10) ];
         
         if strcmp(FinishPassword,'papi') == 1      
            set(GHandles.BlackScreen, 'String', prepareForBlackScreenShow(msg2), 'FontName', 'David');
            exp_state = State.WaitForClick6;
         end
           
    end

    if current_trial <= N_rounds
        plot_current_trial();
        exp_state = State.Work;
        set(GHandles.Hold,'String',' ');
        set(GHandles.Pass,'String',' ');
        set(handles.Round, 'String', current_trial);
        set(save_and_continue,'Enable','off', 'FontName', 'David');
        tic;
    end
    
elseif prac_or_exp == ChooseExpOrPractice.Practice
    current_trial = current_trial + 1;
    if current_trial > N_practices
       set(save_and_continue,'Enable','off', 'FontName', 'David');
       set(GHandles.BlackScreen, 'Visible', 'on');
    
        %exp_state = State.WaitForClick;
        end_of_prac = ['������ ������.'...
                char(10) '��/� �����/� ������ ������.'...
                char(10)...
                char(10) '���/� �� ����� �����'];
        set(GHandles.BlackScreen, 'String', prepareForBlackScreenShow(end_of_prac), 'FontName', 'David');
        exp_state = State.WaitForClick3;
    end
    
    if current_trial <= N_practices
        plot_current_trial();
        exp_state = State.Work;
        set(GHandles.Hold,'String',' ');
        set(GHandles.Pass,'String',' ');
        set(handles.Round, 'String', current_trial);
        set(save_and_continue,'Enable','off', 'FontName', 'David');
    end
end


% % --------------------------------------------------------------------
% function FileMenu_Callback(hObject, eventdata, handles)

% --------------------------------------------------------------------
% function CloseMenuItem_Callback(hObject, eventdata, handles)
% 
% delete(handles.figure1)

function newstr = prepareForBlackScreenShow(str)
    counter =0;
    for i = 1:length(str)
        if str(i) == char(10)
            counter = counter + 1;
        end
    end
    AmountOfChars = 11 - floor(0.5.*counter);
    newstr = '';
    for j = 1:AmountOfChars
        newstr = [newstr  char(10)];
    end
    newstr = [newstr str];

function [retx,rety] = get_closest_point_coordinates(current_point_x, current_point_y)
    global x_ind y_ind current_trial a b axis_lim_y axis_lim_x
    x = current_point_x;
    y = current_point_y;
    
    retx = -1;
    rety = -1;
    
    [~,ind1] = min(abs(x_ind-x));
    if min(abs(x_ind(ind1)-x)) < 0.07.*axis_lim_x && min(abs(y_ind(ind1)-y)) < 0.07.*axis_lim_y
        if (x >= 0 && x <= axis_lim_x && y >= 0 && y <= axis_lim_y)
            [~,offset] = min((x_ind - x).^2 + (y_ind - y).^2); 
            if y_ind(offset) < 0
                intersection_xaxis = -b(current_trial)/a(current_trial);
                retx = round(intersection_xaxis,1); 
                rety = 0;
            else
                retx = round(x_ind(offset),1); 
                rety = round(y_ind(offset),1); 
            end
        elseif (x < 0 && y >= 0)
            retx = 0;
            rety = round(b(current_trial),1); 
        end
    end
    

function mouseMove (object, eventdata)
global hChoice exp_state x_ind y_ind axis_lim_y axis_lim_x
State = struct('WaitForClick',1, 'ExperimentShutdown', 2 ,'WaitForT',3 ,'Work',4, 'WaitForClick2',5,...
        'WaitForClick3',6, 'WaitForClick4',7, 'WaitForClick5',8, 'WaitForClick6',9, 'WaitForClick7',10);

 if exp_state == State.Work
    C = get (gca, 'CurrentPoint');
    x = C(1,1);
    y = C(1,2);
    [retx,rety] = get_closest_point_coordinates(x,y);
    if retx ~= -1 
        title(gca, ['X: ' num2str(retx) ', Y: ' num2str(rety)]);   
        set(gcf, 'pointer', 'fullcrosshair')
    else
        title(gca, ['X:      , Y:   ']);
        set(gcf, 'Pointer', 'arrow');
    end
 end

% --- Executes on mouse press over axes background.
function mytestcallback(hObject, eventdata)

global GHandles axis_lim_x axis_lim_y
global choice current_trial t alpha i_subject a b save_and_continue N_rounds T;
global exp_state prac_or_exp exchange_rate subject_ID
global chosen_trial winning_points_X_str
global winning_points_Y_str winning_prize chosen_axis winning_points

State = struct('WaitForClick',1, 'ExperimentShutdown', 2 ,'WaitForT',3 ,'Work',4, 'WaitForClick2',5,...
        'WaitForClick3',6, 'WaitForClick4',7, 'WaitForClick5',8, 'WaitForClick6',9, 'WaitForClick7',10);

ChooseExpOrPractice = struct('Practice',1, 'Experiment',2); 

if prac_or_exp == ChooseExpOrPractice.Experiment
    if exp_state == State.Work
        C = get (gca, 'CurrentPoint');
        x = C(1,1);
        y = C(1,2);

        [retx,rety] = get_closest_point_coordinates(x,y);

        if retx ~= -1
            set(GHandles.Hold,'String',rety);
            set(GHandles.Pass,'String',retx);

            choice{1,1} = 'Trial';
            choice{1,2} = 'a';
            choice{1,3} = 'b';
            choice{1,4} = 'x';
            choice{1,5} = 'y';
            choice{1,6} = 'Time (sec)';
            choice{1,7} = 't';
            choice{1,8} = 'alpha';
            choice{1,9} = 'i';
            choice{1,10} = 'Axis_lim_x';
            choice{1,11} = 'Axis_lim_y';
        
            choice{current_trial+1, 1} = current_trial;
            choice{current_trial+1, 2} = a(current_trial);
            choice{current_trial+1, 3} = b(current_trial);
            choice{current_trial+1, 4} = retx;
            choice{current_trial+1, 5} = rety;
            %choice{current_trial+1, 6} = toc;
            choice{current_trial+1, 7} = t(current_trial);
            choice{current_trial+1, 8} = alpha(current_trial);
            choice{current_trial+1, 9} = i_subject(current_trial);
            choice{current_trial+1, 10} = axis_lim_x;
            choice{current_trial+1, 11} = axis_lim_y;
        
            set(save_and_continue,'Enable','on', 'FontName', 'David');
        else
            set(GHandles.Hold,'String',' ');
            set(GHandles.Pass,'String',' ');
            set(save_and_continue,'Enable','off', 'FontName', 'David');
        end
        
%     elseif exp_state == State.WaitForClick5    
%         msg2 = ['���� ������ ������ ����� ����: ' ...
%                  char(10) '���� ���� ' num2str(chosen_trial) '.'...
%                  char(10) '��� ��, ����� ������ ���� ���� ' chosen_axis...
%                  char(10) '����� �� ���� ' winning_points_X_str '�������� ����� X, '...
%                  char(10) '�-' winning_points_Y_str '�������� ����� Y.'...
%                  char(10) '����� ���� �-' num2str(winning_points)...
%                  char(10)...
%                  char(10) '��� ����� ������ ��� ' num2str(exchange_rate) ' ������.' ...  
%                  char(10) '��� ���� �-' num2str(winning_prize) '�����.'...
%                  char(10) ...
%                  char(10) '���/� �� ���, ������/�� ����/���� ����.'...
%                  char(10) ];
%                  
%              if strcmp(FinishPassword,'papi') == 1      
%                 set(GHandles.BlackScreen, 'String', prepareForBlackScreenShow(msg2), 'FontName', 'David');
%              end
% %             exp_state = State.WaitForClick6;
             
    elseif exp_state == State.WaitForClick6
        tmp = datestr(clock);
        tmp(tmp==':') = '_';
%         path = '\\nihul-term\Dino\';
%         path =  'C:\Users\User\Dropbox\LabDropbox\vered\GARP Comparative\Kariv\Risk preferences_no prize\';
           path =  '\\HAPP1\Experiments\experiments\Dotan\Vered\';
            if isempty(subject_ID)
                xlswrite([path tmp '.xls'], choice);
            else
                xlswrite([path char(subject_ID) ' ' tmp '.xls'], choice);
            end
        delete(GHandles.BlackScreen);
        close all;
        exit;
    end
    
elseif prac_or_exp == ChooseExpOrPractice.Practice
    if exp_state == State.Work
        C = get (gca, 'CurrentPoint');
        x = C(1,1);
        y = C(1,2);

        [retx,rety] = get_closest_point_coordinates(x,y);

        if retx ~= -1
            set(GHandles.Hold,'String',rety);
            set(GHandles.Pass,'String',retx);
            set(save_and_continue,'Enable','on', 'FontName', 'David');
        else
            set(GHandles.Hold,'String',' ');
            set(GHandles.Pass,'String',' ');
            set(save_and_continue,'Enable','off', 'FontName', 'David');
        end
    elseif exp_state == State.WaitForClick
        practice_details = ['���� ��� ������, �����/� ����� ���, �� ��� ����� ����� ����.'...
                            char(10) ...
                            char(10) '������ ����� 5 ����� �����.'...
                            char(10) ...
                            char(10) '���/� �� ����� �����'];
        set(GHandles.BlackScreen, 'String', prepareForBlackScreenShow(practice_details), 'FontName', 'David');
        exp_state = State.WaitForClick2;
        %pause(5)

    elseif exp_state == State.WaitForClick2
        set(GHandles.BlackScreen, 'Visible', 'off');
        plot_current_trial()
        exp_state = State.Work;
        tic;
        
    elseif exp_state == State.WaitForClick3
        experiment_details = ['������ �� ����/� �� ' num2str(N_rounds) ' ����� �����.' ...
                                char(10) '��� ����� ��� �������� ������ ����� ���� ' num2str(exchange_rate) ' ������.'...
                                char(10)...
                                char(10)  '���/� �� ����� �����'];
        set(GHandles.BlackScreen, 'String', prepareForBlackScreenShow(experiment_details), 'FontName', 'David');
        %pause(5)
        exp_state = State.WaitForClick4;
        
    elseif exp_state == State.WaitForClick4   
        prac_or_exp = ChooseExpOrPractice.Experiment;
        % Budgetr sets lottery for both the experiment
        current_trial = 1;
        line_ctr = 1;
        t = zeros(N_rounds,1); % t represents the current_trial's slope
        i_subject =  zeros(N_rounds,1); % i represents which player will have a price of 1
        alpha =  zeros(N_rounds,1); % alpha represents the current_trial's endowment
        a = zeros(N_rounds,1);
        b = zeros(N_rounds,1);
        while line_ctr < N_rounds + 1
            i_subject(line_ctr) = randi(2);
            t(line_ctr) = randi(T);
            alpha(line_ctr) = randi([40 100]);    
            if i_subject(line_ctr)==1
                b_tmp = alpha(line_ctr);
                tmp = alpha(line_ctr).*t(line_ctr);
                a_tmp = -(b_tmp)/(tmp);
            else
                b_tmp = alpha(line_ctr).*t(line_ctr);
                tmp = alpha(line_ctr);
                a_tmp = -(b_tmp)/(tmp);
            end
            b(line_ctr) = b_tmp;
            a(line_ctr) = a_tmp;
            line_ctr = line_ctr + 1;
        end
        choice = cell(length(a)+8,12);
        set(GHandles.Round, 'String', 1);
        %set(save_and_continue,'Enable','off', 'FontName', 'David');
        plot_current_trial()
        set(GHandles.RoundsPerSessionTxt,'String',N_rounds);
        set(GHandles.BlackScreen, 'Visible', 'off');
        exp_state = State.Work;
        tic;
    end
end



% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over BlackScreen.
function BlackScreen_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to BlackScreen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
