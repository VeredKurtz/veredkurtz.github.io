classdef ChooseExpOrPractice
   enumeration
      Practice, Experiment
   end
end