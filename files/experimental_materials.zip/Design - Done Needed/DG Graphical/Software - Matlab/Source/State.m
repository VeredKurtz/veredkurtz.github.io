classdef State
   enumeration
      WaitForClick, ExperimentShutdown, WaitForT, Work
   end
end